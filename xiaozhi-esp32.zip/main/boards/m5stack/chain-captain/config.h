#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

// M5Stack Chain Captain Board configuration

#include <driver/gpio.h>


#define AUDIO_INPUT_REFERENCE       true
#define AUDIO_INPUT_SAMPLE_RATE     24000
#define AUDIO_OUTPUT_SAMPLE_RATE    24000
#define AUDIO_CODEC_ES8311_ADDR     ES8311_CODEC_DEFAULT_ADDR

#define AUDIO_CODEC_I2C_SCL_PIN     GPIO_NUM_2
#define AUDIO_CODEC_I2C_SDA_PIN     GPIO_NUM_3

#define AUDIO_I2S_GPIO_MCLK         GPIO_NUM_40
#define AUDIO_I2S_GPIO_WS           GPIO_NUM_41
#define AUDIO_I2S_GPIO_BCLK         GPIO_NUM_38
#define AUDIO_I2S_GPIO_DIN          GPIO_NUM_39
#define AUDIO_I2S_GPIO_DOUT         GPIO_NUM_42
#define AUDIO_CODEC_GPIO_PA         GPIO_NUM_21

#define DISPLAY_BACKLIGHT_PIN   GPIO_NUM_NC // M5IOE1_G11
#define DISPLAY_RST_PIN         GPIO_NUM_NC // M5IOE1_G4
#define DISPLAY_MOSI_PIN        GPIO_NUM_16
#define DISPLAY_CLK_PIN         GPIO_NUM_15
#define DISPLAY_DC_PIN          GPIO_NUM_46
#define DISPLAY_CS_PIN          GPIO_NUM_45

// M5GFX Chain Captain: 240x320 RAM, 240x240 visible area, rotation offset 2.
#define DISPLAY_WIDTH                   240
#define DISPLAY_HEIGHT                  240
#define DISPLAY_MIRROR_X                true
#define DISPLAY_MIRROR_Y                true
#define DISPLAY_SWAP_XY                 false
#define DISPLAY_INVERT_COLOR            false
#define DISPLAY_RGB_ORDER               LCD_RGB_ELEMENT_ORDER_RGB
// With 180-degree rotation, M5GFX maps the visible area to GRAM rows 80-319.
#define DISPLAY_PANEL_GAP_X             0
#define DISPLAY_PANEL_GAP_Y             80
#define DISPLAY_OFFSET_X                0
#define DISPLAY_OFFSET_Y                0
#define DISPLAY_BACKLIGHT_OUTPUT_INVERT false
#define DISPLAY_SPI_MODE                0

#define BUILTIN_LED_GPIO        GPIO_NUM_NC
#define USER_BUTTON_GPIO        GPIO_NUM_4
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_1
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_5

// M5IOE1 pin
#define IOE_PIN_LCD_POWER       M5IOE1_PIN_12
#define IOE_PIN_LCD_RESET       M5IOE1_PIN_1
#define IOE_PIN_BACKLIGHT       M5IOE1_PIN_11 // PWM_CH3
#define IOE_PIN_CODEC_POWER     M5IOE1_PIN_5

// M5PM1 pin
#define PMIC_PIN_CHARGE_STATE   M5PM1_GPIO_NUM_0
#define PMIC_PIN_BOOST_ENABLE   M5PM1_GPIO_NUM_3

#endif // _BOARD_CONFIG_H_
